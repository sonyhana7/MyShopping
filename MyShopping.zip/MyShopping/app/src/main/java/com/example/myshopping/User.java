package com.example.myshopping;

public class User {
    String matricno,phone,username,email,password,location,latitude,longitude;
    User(String m, String ph,String n,String e, String p,String l,String la, String lg){
        matricno=m;
        phone= ph;
        username = n;
        email = e;
        password = p;
        location = l;
        latitude= la;
        longitude = lg;


    }
}
