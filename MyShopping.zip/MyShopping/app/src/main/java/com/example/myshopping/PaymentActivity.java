package com.example.myshopping;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {
    String email,username,phone,total,orderid;
    WebView simpleWebView;
    boolean loadingFinished = true;
    boolean redirect = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        email = bundle.getString("email");
        username = bundle.getString("username");
        phone = bundle.getString("phone");
        total = bundle.getString("total");
        orderid = bundle.getString("orderid");
        simpleWebView = (WebView) findViewById(R.id.wbview);
        simpleWebView.setWebViewClient(new MyWebViewClient());

        String url = "http://www.nrhnabdwhb.com/mefs2/php/payment.php?" +
                "email="+email+"&phone="+phone+"&username="+username+"&amount="+total+"&orderid="+orderid;
        simpleWebView.getSettings().setJavaScriptEnabled(true);
        simpleWebView.loadUrl(url); // load the url on the web view
    }

    private class MyWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.e("SIMPLE","shouldOverrideUrlLoading");

            if (!loadingFinished) {
                redirect = true;
            }
            loadingFinished = false;
            view.loadUrl(url); // load the url
            return true;
        }
        @Override
        public void onPageStarted(WebView view, String url, Bitmap facIcon) {
            Log.e("SIMPLE","onPageStarted");
            loadingFinished = false;

            //SHOW LOADING IF IT ISNT ALREADY VISIBLE
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            Log.e("SIMPLE","onPageFinished");
            if(!redirect){
                loadingFinished = true;
            }

            if(loadingFinished && !redirect){
                //HIDE LOADING IT HAS FINISHED
                //Toast.makeText(PaymentActivity.this, "Loading completed", Toast.LENGTH_SHORT).show();
            } else{
                redirect = false;
                Toast.makeText(PaymentActivity.this, "Redirecting..", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_payment, menu);
        return true;
    }
    //@Override
   // public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
      //  switch (item.getItemId()) {
          // case R.id.menu_refresh:
               // loadPayment();
              //  return true;
          //  default:
           //    return super.onOptionsItemSelected(item);
    //   }
   // }

    private void loadPayment() {
        String url = "http://www.simplehlife.com/uniShop/php/payment.php?" +
                "email="+email+"&phone="+phone+"&username="+username+"&amount="+total+"&orderid="+orderid;
        simpleWebView.getSettings().setJavaScriptEnabled(true);
        simpleWebView.loadUrl(url); // load the url on the web view
    }

}
